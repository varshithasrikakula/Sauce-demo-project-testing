package Automation;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Project_by_Sai_Subash {
    public static void main(String[] args) {
        // Set up the WebDriver and navigate to the Saucedemo login page
        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();

        try {
            // Navigate to the Saucedemo website
            driver.get("https://www.saucedemo.com/v1/index.html");
            System.out.println("Navigated to Saucedemo website.");
            Thread.sleep(2000);

            // Enter the username
            WebElement usernameInput = driver.findElement(By.id("user-name"));
            usernameInput.sendKeys("standard_user");
            System.out.println("Entered username.");
            Thread.sleep(2000);

            // Enter the password
            WebElement passwordInput = driver.findElement(By.id("password"));
            passwordInput.sendKeys("secret_sauce");
            System.out.println("Entered password.");
            Thread.sleep(2000);

            // Click the login button
            WebElement loginButton = driver.findElement(By.id("login-button"));
            loginButton.click();
            System.out.println("Clicked login button.");
            Thread.sleep(2000);

            // Press on the name/title of the product
            WebElement productTitle = driver.findElement(By.id("item_4_title_link"));
            productTitle.click();
            System.out.println("Clicked on product title.");
            Thread.sleep(2000);

            // Press Back from the product page
            WebElement backButton = driver.findElement(By.className("inventory_details_back_button"));
            backButton.click();
            System.out.println("Pressed back button from product page.");
            Thread.sleep(2000);

            // Locate a different image by its 'src' attribute and click on it
            WebElement productImage = driver.findElement(By.xpath("//img[@src='./img/bolt-shirt-1200x1500.jpg']"));
            productImage.click();
            System.out.println("Clicked on product image.");
            Thread.sleep(2000);

            // Press Back from the product page
            WebElement backButton1 = driver.findElement(By.className("inventory_details_back_button"));
            backButton1.click();
            System.out.println("Pressed back button again from product page.");
            Thread.sleep(2000);

            // Open the menu bar
            WebElement menuButton1 = driver.findElement(By.className("bm-burger-button"));
            menuButton1.click();
            System.out.println("Opened menu bar.");
            Thread.sleep(2000);

            // Click on the logout button
            WebElement logoutButton = driver.findElement(By.id("logout_sidebar_link"));
            logoutButton.click();
            System.out.println("Logged out.");
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        } finally {
            // Close the browser
            driver.quit();
            System.out.println("Browser closed.");
        }
    }
}
