package Automation;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Project_by_Prathibha {
    public static void main(String[] args) {
        // Set up the WebDriver and navigate to the Saucedemo login page
        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();

        try {
            // Navigate to the Saucedemo website
            driver.get("https://www.saucedemo.com/v1/index.html");
            System.out.println("Navigated to Saucedemo website.");
            Thread.sleep(2000);

            // Enter the username
            WebElement usernameInput = driver.findElement(By.id("user-name"));
            usernameInput.sendKeys("standard_user");
            System.out.println("Entered username: standard_user.");
            Thread.sleep(2000);

            // Enter the password
            WebElement passwordInput = driver.findElement(By.id("password"));
            passwordInput.sendKeys("secret_sauce");
            System.out.println("Entered password: secret_sauce.");
            Thread.sleep(2000);

            // Click the login button
            WebElement loginButton = driver.findElement(By.id("login-button"));
            loginButton.click();
            System.out.println("Clicked login button.");
            Thread.sleep(2000);

            // Filter for Name from Z to A
            WebElement filterDropdown = driver.findElement(By.className("product_sort_container"));
            Select filterSelect = new Select(filterDropdown);
            filterSelect.selectByVisibleText("Name (Z to A)");
            System.out.println("Filtered products by Name (Z to A).");
            Thread.sleep(2000);

            // Filter for Price from low to high
            WebElement filterDropdown1 = driver.findElement(By.className("product_sort_container"));
            Select filterSelect1 = new Select(filterDropdown1);
            filterSelect1.selectByVisibleText("Price (low to high)");
            System.out.println("Filtered products by Price (low to high).");
            Thread.sleep(2000);

            // Directly locate and click the "Add to Cart" button for "Sauce Labs Onesie"
            WebElement addToCartButton = driver.findElement(By.xpath("//div[text()='Sauce Labs Onesie']/ancestor::div[contains(@class, 'inventory_item')]//button[text()='ADD TO CART']"));
            addToCartButton.click();
            System.out.println("Clicked 'Add to Cart' button for Sauce Labs Onesie.");
            Thread.sleep(2000);

            // Click on the cart icon to view the cart
            WebElement cartIcon = driver.findElement(By.id("shopping_cart_container"));
            cartIcon.click();
            System.out.println("Clicked on cart icon.");
            Thread.sleep(2000);

            // View "Sauce Labs Onesie" in the cart
            WebElement productName = driver.findElement(By.xpath("//div[contains(@class, 'cart_item')]//div[contains(@class, 'inventory_item_name') and text()='Sauce Labs Onesie']"));
            productName.click();
            System.out.println("Viewed 'Sauce Labs Onesie' in the cart.");
            Thread.sleep(2000);

            // Press Back from the product page
            WebElement backButton2 = driver.findElement(By.className("inventory_details_back_button"));
            backButton2.click();
            System.out.println("Pressed back button from product page.");
            Thread.sleep(2000);

            // Open the menu bar
            WebElement menuButton1 = driver.findElement(By.className("bm-burger-button"));
            menuButton1.click();
            System.out.println("Opened menu bar.");
            Thread.sleep(2000);

            // Click on the logout button
            WebElement logoutButton = driver.findElement(By.id("logout_sidebar_link"));
            logoutButton.click();
            System.out.println("Clicked on logout button.");
            Thread.sleep(2000);

        } catch (InterruptedException e) {
            e.printStackTrace();
        } finally {
            // Close the browser
            driver.quit();
            System.out.println("Browser closed.");
        }
    }
}
