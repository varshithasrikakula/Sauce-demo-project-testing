package Automation;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import java.time.Duration;

public class Project_by_Saloni_Sharma {
    private WebDriver driver;

    public void setup() {
        try {
            // Setup ChromeDriver with WebDriverManager
            
            driver = new ChromeDriver();
            System.out.println("Driver initialized: " + (driver != null));  // Debugging line

            // Maximize the browser window
            driver.manage().window().maximize();

            // Set implicit wait
            driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

            // Open the website
            driver.get("https://www.saucedemo.com/v1/index.html");
            System.out.println("Website loaded successfully");
        } catch (Exception e) {
            System.out.println("Error in setup: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public void testLongPasswordLogin() {
        setup();
        if (driver == null) {
            System.out.println("Driver is null, aborting test");
            return;
        }
        try {
            WebElement usernameField = driver.findElement(By.id("user-name"));
            usernameField.sendKeys("standard_user");

            WebElement passwordField = driver.findElement(By.id("password"));
            passwordField.sendKeys("thisisaverylongpasswordthatexceedsthecharacterlimit");

            WebElement loginButton = driver.findElement(By.id("login-button"));
            loginButton.click();

            WebElement error = driver.findElement(By.xpath("//h3[@data-test='error']"));
            System.out.println("Error displayed: " + error.getText());
        } catch (Exception e) {
            System.out.println("Error during testLongPasswordLogin: " + e.getMessage());
            e.printStackTrace();
        } 
    }

    public void testValidLogin() {
        setup();
        if (driver == null) {
            System.out.println("Driver is null, aborting test");
            return;
        }
        try {
            WebElement usernameField = driver.findElement(By.id("user-name"));
            usernameField.sendKeys("standard_user");

            WebElement passwordField = driver.findElement(By.id("password"));
            passwordField.sendKeys("secret_sauce");

            WebElement loginButton = driver.findElement(By.id("login-button"));
            loginButton.click();

            if (driver.getCurrentUrl().contains("inventory.html")) {
                System.out.println("Logged into SauceDemo successfully.");
            } else {
                System.out.println("Login failed.");
            }
        } catch (Exception e) {
            System.out.println("Error during testValidLogin: " + e.getMessage());
            e.printStackTrace();
        } 
    }

    public static void main(String[] args) {
        Project_by_Saloni_Sharma tests = new Project_by_Saloni_Sharma();
        tests.testLongPasswordLogin();  // Test for long password error
        tests.testValidLogin();         // Test for successful login
    }
}