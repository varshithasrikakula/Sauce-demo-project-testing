package Automation;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Project_by_U_Ramesh {
    public static void main(String[] args) {
        // Set up the WebDriver and navigate to the Saucedemo login page
        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();

        try {
            // Navigate to the Saucedemo website
            driver.get("https://www.saucedemo.com/v1/index.html");
            System.out.println("Navigated to Saucedemo website.");
            Thread.sleep(2000);

            // Enter the username
            WebElement usernameInput = driver.findElement(By.id("user-name"));
            usernameInput.sendKeys("standard_user");
            System.out.println("Entered username: standard_user.");
            Thread.sleep(2000);

            // Enter the password
            WebElement passwordInput = driver.findElement(By.id("password"));
            passwordInput.sendKeys("secret_sauce");
            System.out.println("Entered password: secret_sauce.");
            Thread.sleep(2000);

            // Click the login button
            WebElement loginButton = driver.findElement(By.id("login-button"));
            loginButton.click();
            System.out.println("Clicked login button.");
            Thread.sleep(2000);

            // Locate and click the "Add to Cart" button for "Sauce Labs Onesie"
            WebElement addToCartButton = driver.findElement(By.xpath("//div[text()='Sauce Labs Onesie']/ancestor::div[contains(@class, 'inventory_item')]//button[text()='ADD TO CART']"));
            addToCartButton.click();
            System.out.println("Clicked 'Add to Cart' button for Sauce Labs Onesie.");
            Thread.sleep(2000);

            // Locate and click the "Add to Cart" button for "Sauce Labs Bike Light"
            WebElement addToCartButton1 = driver.findElement(By.xpath("//div[text()='Sauce Labs Bike Light']/ancestor::div[contains(@class, 'inventory_item')]//button[text()='ADD TO CART']"));
            addToCartButton1.click();
            System.out.println("Clicked 'Add to Cart' button for Sauce Labs Bike Light.");
            Thread.sleep(2000);

            // Optionally, click on the cart icon to view the cart
            WebElement cartIcon = driver.findElement(By.id("shopping_cart_container"));
            cartIcon.click();
            System.out.println("Clicked on cart icon.");
            Thread.sleep(2000);

            // Locate and click the "Remove" button for the "Sauce Labs Bike Light"
            WebElement removeButton = driver.findElement(By.xpath("//div[text()='Sauce Labs Bike Light']/ancestor::div[contains(@class, 'cart_item')]//button[text()='REMOVE']"));
            removeButton.click();
            System.out.println("Clicked 'Remove' button for Sauce Labs Bike Light.");
            Thread.sleep(2000);

            // Open the menu bar
            WebElement menuButton1 = driver.findElement(By.className("bm-burger-button"));
            menuButton1.click();
            System.out.println("Opened menu bar.");
            Thread.sleep(2000);

            // Click on the logout button
            WebElement logoutButton = driver.findElement(By.id("logout_sidebar_link"));
            logoutButton.click();
            System.out.println("Clicked on logout button.");
            Thread.sleep(2000);

        } catch (InterruptedException e) {
            e.printStackTrace();
        } finally {
            // Close the browser
            driver.quit();
            System.out.println("Browser closed.");
        }
    }
}
