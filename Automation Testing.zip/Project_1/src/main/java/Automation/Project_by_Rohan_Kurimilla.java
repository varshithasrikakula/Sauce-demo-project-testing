package Automation;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Project_by_Rohan_Kurimilla {
    public static void main(String[] args) {
        // Set up the WebDriver and navigate to the Saucedemo login page
        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();
        
        try {
            // Navigate to the Saucedemo website
            driver.get("https://www.saucedemo.com/v1/index.html");
            Thread.sleep(2000);

            //Check character limit for username and password
            checkCharacterLimit(driver, "user-name", 20); // Example max length
            checkCharacterLimit(driver, "password", 20); // Example max length

            // Test with correct credentials
            login(driver, "standard_user", "secret_sauce");
            performActions(driver);
            logout(driver);

            // Test with incorrect credentials
            login(driver, "wrong_user", "wrong_password");
            verifyErrorMessage(driver, "Epic sadface: Username and password do not match any user in this service");

        } catch (InterruptedException e) {
            e.printStackTrace();
        } finally {
            // Close the browser
            driver.quit();
        }
    }

    private static void login(WebDriver driver, String username, String password) throws InterruptedException {
        // Enter the username
        WebElement usernameInput = driver.findElement(By.id("user-name"));
        usernameInput.clear(); // Clear any existing text
        usernameInput.sendKeys(username);
        Thread.sleep(2000);

        // Enter the password
        WebElement passwordInput = driver.findElement(By.id("password"));
        passwordInput.clear(); // Clear any existing text
        passwordInput.sendKeys(password);
        Thread.sleep(2000);

        // Click the login button
        WebElement loginButton = driver.findElement(By.id("login-button"));
        loginButton.click();
        Thread.sleep(2000);
    }

    private static void performActions(WebDriver driver) throws InterruptedException {
        // Perform actions like filtering, adding/removing items from the cart, and checking out
        // Add your existing actions here
    }

    private static void logout(WebDriver driver) throws InterruptedException {
        // Open the menu bar
        WebElement menuButton = driver.findElement(By.className("bm-burger-button"));
        menuButton.click();
        Thread.sleep(2000);

        // Click on the logout button
        WebElement logoutButton = driver.findElement(By.id("logout_sidebar_link"));
        logoutButton.click();
        Thread.sleep(2000);
    }

    private static void checkCharacterLimit(WebDriver driver, String fieldId, int maxLength) {
        WebElement field = driver.findElement(By.id(fieldId));
        String maxLengthAttribute = field.getAttribute("maxlength");
        if (maxLengthAttribute != null && Integer.parseInt(maxLengthAttribute) == maxLength) {
            System.out.println("Character limit validation for " + fieldId + " is correct.");
        } else {
            System.out.println("Character limit validation for " + fieldId + " is incorrect.");
        }
    }

    private static void verifyErrorMessage(WebDriver driver, String expectedMessage) throws InterruptedException {
        // Assuming error message is displayed in an element with a specific class or id
        WebElement errorMessageElement = driver.findElement(By.cssSelector("h3[data-test='error']"));
        String actualMessage = errorMessageElement.getText();
        if (actualMessage.equals(expectedMessage)) {
            System.out.println("Error message is displayed correctly: " + actualMessage);
        } else {
            System.out.println("Error message is incorrect. Expected: " + expectedMessage + ", but got: " + actualMessage);
        }
        Thread.sleep(2000); // Pause for 2 seconds
    }
}
